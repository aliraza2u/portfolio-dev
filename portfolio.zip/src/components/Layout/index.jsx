import * as React from "react";
import PropTypes from "prop-types";
import Box from "@mui/material/Box";
import CssBaseline from "@mui/material/CssBaseline";
import Drawer from "@mui/material/Drawer";
import IconButton from "@mui/material/IconButton";
import List from "@mui/material/List";
import ListItem from "@mui/material/ListItem";
import ListItemButton from "@mui/material/ListItemButton";
import ListItemIcon from "@mui/material/ListItemIcon";
import ListItemText from "@mui/material/ListItemText";
import MenuIcon from "@mui/icons-material/Menu";
import HomeIcon from "@mui/icons-material/Home";
import PermIdentityIcon from "@mui/icons-material/PermIdentity";
import MedicalInformationIcon from "@mui/icons-material/MedicalInformation";
import SchoolIcon from "@mui/icons-material/School";
import WorkIcon from "@mui/icons-material/Work";
import CallIcon from "@mui/icons-material/Call";
import Home from "../Home/Index.jsx";
import About from "../About/Index.jsx";
import Skill from "../Skill/Index.jsx";
import Services from "../Services";
import Experience from "../Experience/Index.jsx";
import Contact from "../Contact/Index.jsx";
import Project from "../Projects";
import Client from "../Client/Index.jsx";

import "./Layout.css";

const drawerWidth = 300;

function Layout(props) {
  const [mobileOpen, setMobileOpen] = React.useState(false);

  const handleDrawerToggle = () => {
    setMobileOpen(!mobileOpen);
  };

  const drawer = (
    <div className="sidebar-wrap">
      <div className="logo">
        <img src="/img/logo-dark.png" alt="Not available" />
      </div>
      <List>
        {SIDEBAR_ITEMS.map((element) => (
          <a key={element.title} href={element.href} >
            <ListItemButton>
              <ListItemIcon>
                <b style={{ color: "#FF4C60" }}>{element.icon}</b>
              </ListItemIcon>
              <ListItemText>
                <b style={{ color: "#454360" }}>{element.title}</b>
              </ListItemText>
            </ListItemButton>
          </a>
        ))}
      </List>
    </div>
  );

  return (
    <Box sx={{ display: "flex" }}>
      <CssBaseline />
      <IconButton
        color="inherit"
        aria-label="open drawer"
        edge="start"
        onClick={handleDrawerToggle}
        sx={{
          mr: 2,
          display: { sm: "none" },
          "@media(max-width:768px)": {
            display: "none",
          },
        }}
      >
        <MenuIcon />
      </IconButton>
      <Box
        component="nav"
        sx={{
          width: { sm: drawerWidth },
          flexShrink: { sm: 0 },
          "@media(max-width:768px)": {
            margin: "0",
            padding: "0",
          },
        }}
        aria-label="mailbox folders"
      >
        <Drawer
          variant="permanent"
          sx={{
            display: { xs: "none", sm: "block" },
            "& .MuiDrawer-paper": {
              backgroundColor: "#f9f9ff",
              boxSizing: "border-box",
              width: drawerWidth,
            },
          }}
          open
        >
          {drawer}
        </Drawer>
      </Box>
      <div className="block lg:flex justify-center w-full bg-[#f9f9ff]">
        <Box
          component="main"
          sx={{
            flexGrow: 1,
            width: { sm: `calc(100% - ${drawerWidth}px)` },
          }}
          className="2xl:max-w-[1180px]"
        >
          <Home />
          <About />
          <Skill />
          <Services />
          <Experience />
          <Project />
          {/* <Slider /> */}
          <Client />
          <Contact />
        </Box>
      </div>
    </Box>
  );
}

Layout.propTypes = {
  window: PropTypes.func,
};

export default Layout;

const SIDEBAR_ITEMS = [
  {
    title: "Home",
    href: "#home",
    icon: <HomeIcon />,
  },

  {
    title: "About",
    href: "#about",
    icon: <PermIdentityIcon />,
  },
  {
    title: "Services",
    href: "#services",
    icon: <MedicalInformationIcon />,
  },
  {
    title: "Experience",
    href: "#experience",
    icon: <SchoolIcon />,
  },
  {
    title: "Work",
    href: "#work",
    icon: <WorkIcon />,
  },
  {
    title: "Contact",
    href: "#contact",
    icon: <CallIcon />,
  },
];
